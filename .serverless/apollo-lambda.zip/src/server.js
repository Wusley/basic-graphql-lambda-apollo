"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = void 0;
var server_1 = require("@apollo/server");
var aws_lambda_1 = require("@as-integrations/aws-lambda");
// The GraphQL schema
var typeDefs = "#graphql\n  type Query {\n    hello: String\n    hey: String\n    xp: String\n    ho: String\n  }\n";
function hey() {
    return 'you';
}
function char() {
    return 'to';
}
function ho() {
    return 'ho';
}
// A map of functions which return data for the schema.
var resolvers = {
    Query: {
        hello: function () { return 'world'; },
        hey: hey,
        xp: char,
        ho: function () { return ho(); }
    },
};
// Set up Apollo Server
var server = new server_1.ApolloServer({
    typeDefs: typeDefs,
    resolvers: resolvers,
});
exports.graphqlHandler = (0, aws_lambda_1.startServerAndCreateLambdaHandler)(server);
//# sourceMappingURL=server.js.map